from distutils.core import setup
setup(name='yidaiweiren_msg',version='1.0',description='msg',author='yidaiweiren',py_modules=["Testmsg.recvmsg","Testmsg.sendmsg"])